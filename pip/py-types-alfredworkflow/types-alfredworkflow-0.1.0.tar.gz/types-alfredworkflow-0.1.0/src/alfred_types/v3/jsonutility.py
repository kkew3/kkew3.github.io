__all__ = (
    'AlfredWorkflow',
    'JsonUtility',
)

from typing import List, Union, Optional, Dict, Any

from pydantic import BaseModel, Field


class AlfredWorkflow(BaseModel):
    """
    The JSON format should be enclosed within an `alfredworkflow` object, and
    contain a combination of `arg`, `config` or `variables`.
    """
    arg: Optional[Union[str, List[str]]] = None
    config: Optional[Dict[str, Any]] = None
    variables: Dict[str, str] = Field(default_factory=dict)


class JsonUtility(BaseModel):
    """
    Use the JSON object to modify the flow of data / variables through an
    Alfred workflow, along with dynamically modifying the configuration of the
    attached objects.
    """
    alfredworkflow: AlfredWorkflow
