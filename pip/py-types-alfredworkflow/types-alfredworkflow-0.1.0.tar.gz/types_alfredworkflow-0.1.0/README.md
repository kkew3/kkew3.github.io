Python types based on [pydantic](https://docs.pydantic.dev/latest/) for [Alfred](https://www.alfredapp.com) workflow json responses.
