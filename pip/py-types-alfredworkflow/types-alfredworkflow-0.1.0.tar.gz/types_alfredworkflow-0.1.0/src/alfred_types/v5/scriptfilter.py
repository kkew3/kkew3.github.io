__all__ = (
    'PathIcon',
    'FileIcon',
    'UtiIcon',
    'ModKey',
    'Mod',
    'Action',
    'Text',
    'Item',
    'Cache',
    'ScriptFilter',
)

from typing import Annotated, Optional, List, Dict

from pydantic import BaseModel, AfterValidator, Field

from ..v4.scriptfilter import (
    PathIcon,
    FileIcon,
    UtiIcon,
    ModKey,
    Mod,
    Action,
    Text,
    Item,
    _validate_rerun,
)


class Cache(BaseModel):
    """Caching script filters automatically."""
    seconds: Annotated[int, Field(ge=5, le=86400)]
    loosereload: Optional[bool] = None


class ScriptFilter(BaseModel):
    """A script filter response."""
    rerun: Optional[Annotated[float, AfterValidator(_validate_rerun)]] = None
    cache: Optional[Cache] = None
    skipknowledge: Optional[bool] = None
    items: List[Item]
    variables: Dict[str, str] = Field(default_factory=dict)
