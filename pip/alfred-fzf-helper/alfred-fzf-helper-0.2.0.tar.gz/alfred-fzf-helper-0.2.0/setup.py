from setuptools import setup

setup(
    name='alfred-fzf-helper',
    py_modules=['alfzf'],
    version='0.2.0',
)
